# Eastwood Gate: Start Here

This guide explains how to put Eastwood Gate on the internet, step by step.
You do not need to write any code. You just click buttons and copy and paste.

## What is in this folder?

- **public/** : the pages people see (the developer portal and the gate).
- **functions/** : the "brains" that run on Cloudflare when someone clicks something.
- **migrations/** : a file that sets up the database tables.
- **wrangler.toml** : a settings file. You do not need to change it.

## Part 1: Put the project on GitHub

1. Make a free account at github.com if you don't have one.
2. Click the **+** button, then **New repository**. Name it `eastwood-gate`. Click **Create repository**.
3. Unzip the file you downloaded. Open the `eastwood-gate` folder.
4. On the GitHub page, click **uploading an existing file**. Drag everything inside the `eastwood-gate` folder onto the page. Click **Commit changes**.

## Part 2: Create the Cloudflare Pages project

1. Log in at dash.cloudflare.com.
2. Go to **Workers & Pages**, click **Create**, then **Pages**, then **Connect to Git**.
3. Pick your `eastwood-gate` repository and click **Begin setup**.
4. Fill in these boxes:
   - **Project name**: `eastwoodsecurity` (this makes your address `eastwoodsecurity.pages.dev`; if it's taken, pick another name)
   - **Build command**: leave it empty
   - **Build output directory**: `public`
5. Click **Save and Deploy**. The first deploy will probably work but the portal won't save data yet. That's fine. Keep going.

## Part 3: Create the database (a place to store info)

1. In the Cloudflare dashboard, go to **Storage & Databases → D1 SQL Database** (it may also be under Workers & Pages).
2. Click **Create database**, name it `eastwood-gate`, and click **Create**.
3. Click your new database, then the **Console** tab.
4. Open `migrations/0001_initial.sql` in Notepad (or any text editor). Copy everything.
5. Paste it into the console and click **Execute**. You should see a success message.

## Part 4: Connect the database to your project

1. Go to **Workers & Pages** and click your `eastwoodsecurity` project.
2. Click **Settings**, then **Functions**.
3. Find **D1 database bindings** and click **Add binding**.
4. Variable name: `DB` (exactly this, capital letters).
5. Pick `eastwood-gate` and save.

## Part 5: Make your secret admin key

1. Make up a long, random password. Example: type a long mix of letters and numbers, at least 30 characters. Save it somewhere safe. Do not reuse a password you use anywhere else.
2. In your project, go to **Settings**, then **Variables and Secrets**.
3. Click **Add**. Choose **Secret**.
4. Name: `GATE_ADMIN_KEY`. Value: your long password. Save.

## Part 6: Redeploy

1. Go to **Deployments** in your project.
2. Click the three dots on the latest deployment, then **Retry deployment** (or push any small change to GitHub).
3. Wait until it says **Success**.

## Part 7: Try it!

1. Open `https://eastwoodsecurity.pages.dev` (or your project's address).
2. Type your admin key and click **Continue**.
3. Type your domain (like `mysite.com`) and click **Generate DNS record**.
4. Go to your domain's DNS settings wherever you bought it and add a **TXT** record with the name and value shown.
5. Wait a few minutes, then click **Verify DNS**.
6. Once verified, paste a full link (like `https://mysite.com/secret-page`) and click **Create protected link**.
7. Use the link Eastwood Gate gives you in place of the original link.

## Important: read this before you use it for anything real

- The gate asks for a checkbox and a wiggly-letters code. Bots can sometimes get past these, and the letters are hard for some people to read. It's good for testing, not for protecting really private things yet.
- A gate link alone does not lock a page. The website you're protecting must also check the visitor's pass with the `/api/validate` endpoint on its own server. See the README for details.
