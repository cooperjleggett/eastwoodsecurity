CREATE TABLE IF NOT EXISTS domains (
  id TEXT PRIMARY KEY,
  hostname TEXT NOT NULL UNIQUE,
  verification_token TEXT NOT NULL,
  verified_at INTEGER,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS protected_urls (
  id TEXT PRIMARY KEY,
  domain_id TEXT NOT NULL,
  url_hash TEXT NOT NULL UNIQUE,
  destination_url TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY(domain_id) REFERENCES domains(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS challenges (
  id TEXT PRIMARY KEY,
  url_hash TEXT NOT NULL,
  answer_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS access_tokens (
  token_hash TEXT PRIMARY KEY,
  url_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_urls_domain ON protected_urls(domain_id);
CREATE INDEX IF NOT EXISTS idx_challenges_expiry ON challenges(expires_at);
CREATE INDEX IF NOT EXISTS idx_tokens_expiry ON access_tokens(expires_at);
