import {json,sha256,randomHex} from "../api/_utils.js";
export async function onRequestPost({request,env}){
  const form=await request.formData();
  const hash=String(form.get("url")||""),id=String(form.get("challenge")||"");
  const answer=String(form.get("answer")||"").trim().toUpperCase();
  if(form.get("confirmed")!=="yes" || !/^[a-f0-9]{64}$/.test(hash) || !/^[a-f0-9]{32}$/.test(id) || !/^[A-Z]{6}$/.test(answer))
    return new Response("Verification failed. Return to the gate and try again.",{status:400});
  const now=Math.floor(Date.now()/1000);
  const challenge=await env.DB.prepare("SELECT * FROM challenges WHERE id=? AND url_hash=?").bind(id,hash).first();
  if(!challenge || challenge.expires_at<now || challenge.attempts>=5)
    return new Response("This challenge expired. Return to the gate and try again.",{status:400});
  const match=await sha256(answer)===challenge.answer_hash;
  if(!match){
    await env.DB.prepare("UPDATE challenges SET attempts=attempts+1 WHERE id=?").bind(id).run();
    return new Response("Those characters didn't match. Go back and try a new challenge.",{status:400});
  }
  await env.DB.prepare("DELETE FROM challenges WHERE id=?").bind(id).run();
  const destination=await env.DB.prepare("SELECT destination_url FROM protected_urls WHERE url_hash=?").bind(hash).first();
  if(!destination) return new Response("Protected destination no longer exists.",{status:404});
  const token=randomHex(32),tokenHash=await sha256(token),expires=now+300;
  await env.DB.prepare("INSERT INTO access_tokens(token_hash,url_hash,expires_at,created_at) VALUES(?,?,?,?)")
    .bind(tokenHash,hash,expires,now).run();
  const target=new URL(destination.destination_url);
  target.searchParams.set("eastwood_gate_token",token);
  return Response.redirect(target.href,303);
}
