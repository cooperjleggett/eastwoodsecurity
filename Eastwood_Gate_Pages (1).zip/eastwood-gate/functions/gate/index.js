import {json,sha256,randomHex} from "../api/_utils.js";

function challengePage(hash, challengeId, svg) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Eastwood Gate</title><link rel="stylesheet" href="/gate.css"></head><body><main class="card"><div class="brand"><span class="mark">E</span><span>EASTWOOD GATE<small>BY EASTWOOD SECURITY</small></span></div><div class="rule"></div><p class="eyebrow">SECURITY CHECK</p><h1>Verify that you're human.</h1><p class="muted">Complete the checks below to continue to the requested website.</p><form method="POST" action="/gate/verify"><input type="hidden" name="url" value="${hash}"><input type="hidden" name="challenge" value="${challengeId}"><label class="check"><input type="checkbox" name="confirmed" value="yes" required><span class="fakebox"></span><span>I'm not a robot</span><span class="checkmark">✓</span></label><div class="captcha"><p>Enter the characters shown below</p><div class="captcha-image">${svg}</div><input name="answer" maxlength="6" autocomplete="off" placeholder="Enter 6 characters" required aria-label="Enter the characters shown"><button type="submit">Verify and continue <span>→</span></button></div></form><div class="foot">Protected by <b>Eastwood Gate</b></div></main></body></html>`;
}
function svgCaptcha(code,seed){
  const chars=[...code].map((c,i)=>`<text x="${18+i*31}" y="${42+(i%2?3:-2)}" transform="rotate(${(i%2?1:-1)*((seed+i)%13)} ${18+i*31} 35)">${c}</text>`).join("");
  const lines=Array.from({length:5},(_,i)=>`<path d="M${i*37} ${8+(seed*i)%36} Q${i*41+35} ${i%2?8:42} ${i*30+80} ${12+(seed+i)%30}"/>`).join("");
  return `<svg viewBox="0 0 210 58" role="img" aria-label="Distorted verification characters">${lines}${chars}</svg>`;
}
export async function onRequestGet({request,env}){
  const hash=new URL(request.url).searchParams.get("url")||"";
  if(!/^[a-f0-9]{64}$/.test(hash)) return new Response("Invalid gate link.",{status:400});
  const url=await env.DB.prepare("SELECT url_hash FROM protected_urls WHERE url_hash=?").bind(hash).first();
  if(!url) return new Response("Unknown protected URL.",{status:404});
  const code=randomHex(4).slice(0,6).toUpperCase().replace(/[0-9]/g,c=>String.fromCharCode(65+Number(c)%26));
  const id=randomHex(16),now=Math.floor(Date.now()/1000);
  await env.DB.prepare("DELETE FROM challenges WHERE expires_at<?").bind(now).run();
  await env.DB.prepare("INSERT INTO challenges(id,url_hash,answer_hash,expires_at,created_at) VALUES(?,?,?,?,?)")
    .bind(id,hash,await sha256(code),now+300,now).run();
  const seed=parseInt(id.slice(0,2),16);
  return new Response(challengePage(hash,id,svgCaptcha(code,seed)),{
    headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store","Content-Security-Policy":"default-src 'none'; style-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none';"}
  });
}
