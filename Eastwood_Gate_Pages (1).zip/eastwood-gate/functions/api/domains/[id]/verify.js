import {json,admin,dnsTxt} from "../../_utils.js";
export async function onRequestPost(context){
  if(!(await admin(context))) return json({error:"Invalid administrator key."},401);
  const row=await context.env.DB.prepare("SELECT id,hostname,verification_token FROM domains WHERE id=?")
    .bind(context.params.id).first();
  if(!row) return json({error:"Domain not found."},404);
  try{
    const records=await dnsTxt("_eastwood-gate."+row.hostname);
    if(!records.includes("eastwood-gate-verification="+row.verification_token))
      return json({error:"TXT record not found yet. Check the record name and value, then try again."},400);
    await context.env.DB.prepare("UPDATE domains SET verified_at=? WHERE id=?")
      .bind(Math.floor(Date.now()/1000),row.id).run();
    return json({message:"Domain ownership verified successfully."});
  }catch(e){return json({error:e.message||"DNS verification failed."},502)}
}
