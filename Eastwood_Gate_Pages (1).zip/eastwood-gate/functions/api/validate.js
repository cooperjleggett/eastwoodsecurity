import {json,sha256} from "./_utils.js";

/*
  Server-to-server endpoint. Call this from the protected site's backend,
  not from browser JavaScript. The token is single-use.
*/
export async function onRequestPost({request,env}){
  let body;
  try{body=await request.json()}catch{return json({error:"Invalid JSON."},400)}
  const token=String(body.token||"");
  const suppliedUrl=String(body.url||"");
  if(!/^[a-f0-9]{64}$/.test(token)) return json({valid:false},401);
  let url;
  try{url=new URL(suppliedUrl)}catch{return json({valid:false},400)}
  url.searchParams.delete("eastwood_gate_token");
  const canonical=url.href;
  const urlHash=await sha256(canonical);
  const tokenHash=await sha256(token);
  const now=Math.floor(Date.now()/1000);
  const row=await env.DB.prepare(
    "SELECT token_hash FROM access_tokens WHERE token_hash=? AND url_hash=? AND expires_at>=?"
  ).bind(tokenHash,urlHash,now).first();
  if(!row) return json({valid:false},401);
  await env.DB.prepare("DELETE FROM access_tokens WHERE token_hash=?").bind(tokenHash).run();
  return json({valid:true});
}
