import {json,admin,randomHex,sha256} from "./_utils.js";
export async function onRequestPost(context){
  if(!(await admin(context))) return json({error:"Invalid administrator key."},401);
  let body;try{body=await context.request.json()}catch{return json({error:"Invalid JSON."},400)}
  const domainId=String(body.domain_id||"");
  let parsed;try{parsed=new URL(String(body.url||""))}catch{return json({error:"Enter a valid complete URL."},400)}
  if(parsed.protocol!=="https:" || parsed.username || parsed.password) return json({error:"Only HTTPS URLs without embedded credentials are supported."},400);
  const domain=await context.env.DB.prepare("SELECT id,hostname,verified_at FROM domains WHERE id=?").bind(domainId).first();
  if(!domain || !domain.verified_at) return json({error:"Select a verified domain."},400);
  if(parsed.hostname.toLowerCase()!==domain.hostname && !parsed.hostname.toLowerCase().endsWith("."+domain.hostname))
    return json({error:"The URL hostname must belong to the selected verified domain."},400);
  const destination=parsed.href;
  const hash=await sha256(destination);
  const id=randomHex(12),now=Math.floor(Date.now()/1000);
  try{
    await context.env.DB.prepare("INSERT INTO protected_urls(id,domain_id,url_hash,destination_url,created_at) VALUES(?,?,?,?,?)")
      .bind(id,domain.id,hash,destination,now).run();
  }catch{return json({error:"This exact URL has already been registered."},409)}
  const origin=new URL(context.request.url).origin;
  return json({id,url_hash:hash,gate_url:`${origin}/gate?url=${hash}`});
}
