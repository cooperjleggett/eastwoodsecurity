import {json,admin} from "./_utils.js";
export async function onRequestGet(context){
  if(!(await admin(context))) return json({error:"Invalid administrator key."},401);
  const domains=await context.env.DB.prepare("SELECT id,hostname,verified_at FROM domains ORDER BY created_at DESC").all();
  const urls=await context.env.DB.prepare("SELECT id,url_hash,destination_url,created_at FROM protected_urls ORDER BY created_at DESC").all();
  return json({
    domains:(domains.results||[]).map(d=>({...d,verified:!!d.verified_at})),
    urls:urls.results||[]
  });
}
