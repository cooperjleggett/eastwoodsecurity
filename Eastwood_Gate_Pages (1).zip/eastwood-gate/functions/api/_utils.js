export const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: {"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}
});
export async function sha256(value) {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
export function randomHex(bytes=24) {
  const a=new Uint8Array(bytes); crypto.getRandomValues(a);
  return [...a].map(b=>b.toString(16).padStart(2,"0")).join("");
}
export function validHostname(host) {
  return typeof host==="string" && host.length<=253 &&
    /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(?:\.(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?))+$/.test(host);
}
export async function admin(context) {
  const expected=context.env.GATE_ADMIN_KEY;
  const auth=context.request.headers.get("Authorization")||"";
  const supplied=auth.startsWith("Bearer ")?auth.slice(7):"";
  if(!expected || !supplied || supplied.length!==expected.length) return false;
  const a=new TextEncoder().encode(supplied), b=new TextEncoder().encode(expected);
  let diff=0; for(let i=0;i<a.length;i++) diff|=a[i]^b[i];
  return diff===0;
}
export async function dnsTxt(name) {
  const url="https://cloudflare-dns.com/dns-query?name="+encodeURIComponent(name)+"&type=TXT";
  const r=await fetch(url,{headers:{accept:"application/dns-json"}});
  if(!r.ok) throw new Error("DNS lookup failed. Try again shortly.");
  const data=await r.json();
  return (data.Answer||[]).filter(a=>a.type===16).map(a=>a.data.replace(/^"|"$/g,"").replace(/"\s*"/g,""));
}
