import {json,admin,randomHex,validHostname,dnsTxt} from "./_utils.js";
export async function onRequestPost(context){
  if(!(await admin(context))) return json({error:"Invalid administrator key."},401);
  let body; try{body=await context.request.json()}catch{return json({error:"Invalid JSON."},400)}
  const hostname=String(body.hostname||"").trim().toLowerCase().replace(/\.$/,"");
  if(!validHostname(hostname)) return json({error:"Enter a valid hostname, such as example.com."},400);
  const id=randomHex(12), token=randomHex(24), now=Math.floor(Date.now()/1000);
  try{
    await context.env.DB.prepare("INSERT INTO domains(id,hostname,verification_token,created_at) VALUES(?,?,?,?)")
      .bind(id,hostname,token,now).run();
  }catch{return json({error:"That domain is already registered."},409)}
  return json({id,hostname,record_name:"_eastwood-gate."+hostname,record_value:"eastwood-gate-verification="+token});
}
