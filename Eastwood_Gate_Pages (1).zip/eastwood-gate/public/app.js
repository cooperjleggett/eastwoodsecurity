const $ = id => document.getElementById(id);
$("year").textContent = new Date().getFullYear();
let adminKey = "";
let domains = [];

async function api(path, options={}) {
  const response = await fetch(path, {
    ...options,
    headers: {"Content-Type":"application/json","Authorization":`Bearer ${adminKey}`,...(options.headers||{})}
  });
  const data = await response.json().catch(()=>({error:"Unexpected server response"}));
  if (!response.ok) throw new Error(data.error || "Request failed");
  return data;
}
function show(el, html){el.innerHTML=html;el.classList.remove("hidden")}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

$("loginBtn").onclick = async () => {
  adminKey = $("adminKey").value.trim();
  $("loginMsg").textContent = "";
  if (!adminKey) {$("loginMsg").textContent="Enter your administrator key.";return;}
  try {
    await api("/api/admin");
    $("workspace").classList.remove("hidden");
    $("loginBtn").textContent="Connected";
    $("loginBtn").disabled=true;
    await refresh();
  } catch(e){adminKey="";$("loginMsg").textContent=e.message;}
};
async function refresh(){
  const data=await api("/api/admin");
  domains=data.domains;
  $("domainSelect").innerHTML = domains.filter(d=>d.verified).map(d=>`<option value="${esc(d.id)}">${esc(d.hostname)}</option>`).join("") || `<option value="">No verified domains available</option>`;
  $("domainList").innerHTML=domains.map(d=>`<div class="list-item"><span>${esc(d.hostname)}</span><span class="pill ${d.verified?'good':'bad'}">${d.verified?'Verified':'Awaiting DNS'}</span></div>`).join("");
  $("urlList").innerHTML=data.urls.map(u=>`<div class="list-item"><span>${esc(u.destination_url)}</span><span class="pill">/${esc(u.url_hash.slice(0,12))}…</span></div>`).join("");
}
$("addDomain").onclick=async()=>{
  const hostname=$("hostname").value.trim();
  try{
    const d=await api("/api/domains",{method:"POST",body:JSON.stringify({hostname})});
    show($("dnsResult"),`<strong>Add this TXT record to your DNS</strong><div>Type: <b>TXT</b></div><div>Name: <code>${esc(d.record_name)}</code></div><div>Value: <code>${esc(d.record_value)}</code></div><p>DNS changes can take time to appear. Once added, click Verify DNS.</p><button class="secondary" id="verifyDomain">Verify DNS</button>`);
    $("verifyDomain").onclick=async()=>{
      try{const result=await api(`/api/domains/${encodeURIComponent(d.id)}/verify`,{method:"POST",body:"{}"});$("dnsResult").innerHTML=`<strong class="good">${esc(result.message)}</strong>`;await refresh();}
      catch(e){$("dnsResult").insertAdjacentHTML("beforeend",`<p class="bad">${esc(e.message)}</p>`);}
    };
    await refresh();
  }catch(e){show($("dnsResult"),`<span class="bad">${esc(e.message)}</span>`);}
};
$("protectUrl").onclick=async()=>{
  try{
    const result=await api("/api/urls",{method:"POST",body:JSON.stringify({domain_id:$("domainSelect").value,url:$("targetUrl").value.trim()})});
    show($("urlResult"),`<strong>Protected link created</strong><div>Replace your original link with:</div><code>${esc(result.gate_url)}</code><p>Keep the destination URL on your server. The gate link is an entry point, not a substitute for protecting the destination itself.</p>`);
    await refresh();
  }catch(e){show($("urlResult"),`<span class="bad">${esc(e.message)}</span>`);}
};
