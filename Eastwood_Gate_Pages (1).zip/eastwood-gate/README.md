# Eastwood Gate
**Eastwood Security | Cloudflare Pages + Pages Functions + D1**

This is a deployable starter implementation of Eastwood Gate. It includes:
- Developer portal with administrator-key authentication
- DNS TXT ownership verification
- URL registration and SHA-256 URL identifiers
- A standard two-part visitor challenge
- Short-lived, single-use verification challenges and access tokens

## Important security limitation

Eastwood Gate verifies a visitor and redirects them to the registered destination. **That redirect does not, by itself, protect the destination page.** The destination website must validate the `eastwood_gate_token` server-side against Eastwood Gate's verification service before serving protected content. Do not use this as a substitute for authentication or authorization.

This initial release does not yet expose a public token-introspection endpoint, robust bot scoring, CAPTCHA accessibility alternatives, distributed rate limiting, analytics, or abuse monitoring. The checkbox is an interaction step, not proof of humanity. The text challenge is a basic CAPTCHA and can be solved by automated systems. Treat this as an MVP for testing, not production-grade protection for sensitive pages.

## Deploy to Cloudflare Pages

You need a Cloudflare account.

### 1. Create a D1 database
1. In Cloudflare, open **Workers & Pages → D1 SQL Database**.
2. Create a database named `eastwood-gate`.
No IDs need to be edited in the project files.

### 2. Create an administrator key
Generate a long random password/key. Do not use a password you use elsewhere.

### 3. Deploy the project
Pages Functions require a Functions-capable deployment. The most reliable route is:
1. Upload this ZIP to a new GitHub repository (extract it first).
2. In Cloudflare, open **Workers & Pages → Create → Pages → Connect to Git**.
3. Select the repository.
4. Set the build command to blank / none.
5. Set the build output directory to `public`.
6. Deploy.

### 4. Bind D1
In your Pages project, open **Settings → Functions → D1 database bindings**.
- Variable name: `DB`
- Select the `eastwood-gate` database.
Save and redeploy.

### 5. Add the administrator secret
In **Settings → Variables and Secrets**, add:
- Type: Secret
- Name: `GATE_ADMIN_KEY`
- Value: your generated administrator key

Save and redeploy.

### 6. Create the database tables
1. Open **D1 SQL Database → eastwood-gate → Console**.
2. Open `migrations/0001_initial.sql` in a text editor, copy everything, paste it into the console, and click **Execute**.
3. Redeploy the Pages project once more if prompted.

### 7. Open the portal
Visit your deployed Pages URL. Enter the administrator key. Register your domain, add the TXT record shown, then click **Verify DNS**. Once verified, register an HTTPS URL on that domain.

The generated gate link will look like:

```text
https://eastwoodsecurity.pages.dev/gate?url=64_CHARACTER_SHA256_HASH
```

Replace the original website link with the generated gate link.

## DNS record format

For `example.com`, the portal asks for:
- Type: TXT
- Name: `_eastwood-gate`
- Value: `eastwood-gate-verification=...`

Some DNS providers expect the full record name `_eastwood-gate.example.com`; others append the zone automatically.

## Current behavior and limitations

- Gate challenge expires after 5 minutes.
- Successful verification creates a random access token with a 5-minute lifetime.
- The token is added to the destination URL as `eastwood_gate_token`.
- The token is stored hashed in D1.
- The destination must validate that token server-side. This project includes `POST /api/validate` for server-to-server validation. Send JSON `{ "token": "...", "url": "https://example.com/private-page?eastwood_gate_token=..." }`. The endpoint removes the token parameter, matches the registered destination, checks expiry, and consumes the token. Call it from your website backend, never browser JavaScript. You still need to add this call to the protected website's own server code; Eastwood Gate cannot automatically modify arbitrary websites.
- The challenge page uses a visual character challenge. Add an accessible alternative before real public deployment.
- Do not place sensitive pages behind the redirect alone.

## Project structure

```text
public/             Developer portal and gate styles
functions/api/      Admin, domain and URL APIs
functions/gate/     Visitor challenge and verification
migrations/         D1 schema
wrangler.toml       Pages/D1 configuration
```


## Server-side destination validation

The protected destination must call `POST https://eastwoodsecurity.pages.dev/api/validate` from its own backend before serving protected content. Send JSON with:
- `token`: the `eastwood_gate_token` query parameter
- `url`: the current destination URL, including that token query parameter

A successful response is `{ "valid": true }`. The token is single-use. Any invalid, expired, reused, or mismatched token returns `{ "valid": false }`.

Never call this endpoint from browser JavaScript and never treat the visitor's query parameter alone as proof of verification. The protected site's backend must block access unless the server-to-server validation succeeds. The token is a bearer credential in a URL, so avoid logging full query strings and redirect promptly to a clean URL after validation.


## Eastwood Gate deployment hostname

The intended Pages hostname for this project is:

`https://eastwoodsecurity.pages.dev`

The developer portal generates gate links from the actual request origin, so links will use this hostname when the project is deployed and accessed there.
